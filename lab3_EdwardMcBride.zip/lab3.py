#Edward McBride
#CIS103
#MD ALI
#Date: 10/6/24

#This code is going to take a radius of a sphere which is input by the user and it will calculate the solution.
#We have to define the value of pi.
pi = 3.1415926535897931
#Now the user will input the radius of the sphere
r = float(input('radius:'))
#Now we will calculate the volume of the sphere using the formula
V = 4.0/3.0 * pi * r**3
#Now we print the calculate volume of the sphere
print('The volume of the sphere is: ', V)