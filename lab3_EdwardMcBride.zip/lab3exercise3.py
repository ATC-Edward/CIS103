#Edward McBride
#CIS103
#Proffesor MD ALI
#Date 10/5/4

#This code will print the median of the numbers that are input into the code.
n_num = [65, 35, 45, 67, 98]
n = len(n_num)
n_num.sort()
if n % 2 == 0:
    median1 = n_num[n//2]
    median2 = n_num[n//2 - 1]
    median = (median1 + median2)/2
else:
    median = n_num[n//2]
print('Median is:' + str(median))