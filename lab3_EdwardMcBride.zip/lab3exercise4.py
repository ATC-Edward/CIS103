#Edward McBride
#CIS103
#Proffessor MD ALI
#Date: 10/5/2024

#This code will calculate the mode for the numbers that I input.
#With this next line we will be importing a code from the Python library
from collections import Counter
#I am listing the numbers that will be used to get the mode.
n_num = [25, 15, 35, 25]
n = len(n_num)
data = Counter(n_num)
get_mode = dict(data)
mode = [k for k, v in get_mode.items() if v == max(list(data.values()))]
if len(mode) == n:
    get_mode = 'No mode found'
else:
    get_mode = 'Mode is / are: ' + ', '.join(map(str, mode))
print(get_mode)