#Edward McBride
#CIS103
#Proffessor: MD ALI
#Date: 10/5/2024

import math
def sphere_calculations(radius):
    'Calculates and prints the diameter, circumference, surface area, and volume of a sphere.'
    diameter = 2 * radius
    circumference = 2 * math.pi * radius
    surface_area = 4 * math.pi * radius**2
    volume = (4/3) * math.pi * radius**3
    print('Diameter:', diameter)
    print('Circumference:', circumference)
    print('Surface Area:', surface_area)
    print('volume:', volume)
if __name__ == '__main__':
    radius = float(input('Enter the radius of the sphere:'))
    sphere_calculations(radius)