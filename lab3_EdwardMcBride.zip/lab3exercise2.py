#Edward McBride
#CIS103
#Proffesor MD ALI
#Date: 10/5/2024
#This code will get the median, mode and mean of a list of numbers.
#Now I have to list the elements that I am trying to get the mean median and mode for.
n_num = [98, 57, 25, 45, 67]
n = len(n_num)
get_sum = sum(n_num)
mean = get_sum / n
print('Mean / Average is:' + str(mean))
